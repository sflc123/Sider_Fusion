function setupModel(data) {
  const model = data.scene.children[0];
  return model;
}

export { setupModel };
