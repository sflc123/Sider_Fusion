import * as THREE from "three";

import { ImprovedNoise } from "three/examples/jsm/math/ImprovedNoise.js";
// import { useScannerDataStore } from "@/store/modules/scannerData";
import Urls from "@/store/urls";
import axios from "axios";
const scannerDataUrl = Urls.ScannerData.GetArray;

let cnt = 0;
let ground, texture;

const multi = 13;
const groundHeight = 64;
const groundWidth = 17;
const worldWidth = multi * groundHeight,
  worldDepth = multi * groundWidth + 1;

function loadGround() {
  const data = generateHeight(worldWidth, worldDepth);
  // const data = await axios.get(scannerDataUrl);
  const geometry = new THREE.PlaneBufferGeometry(
    groundHeight, //料场的长度
    groundWidth, //料场的宽度
    worldWidth - 1,
    worldDepth - 1
  );
  geometry.rotateX(-Math.PI / 2);

  const vertices = geometry.attributes.position.array;

  const begin = worldWidth * (worldDepth - 1);
  const end = begin + worldWidth;
  for (let i = begin; i < end; i++) {
    data[i] = 0;
  }

  console.log("vertices", vertices);
  console.log("data", data);

  for (let i = 0, j = 0, l = vertices.length; i < l; i++, j += 3) {
    vertices[j + 0] = (i % (multi * groundHeight)) / multi - groundHeight / 2; // 设置长度方向的坐标
    vertices[j + 1] = data[i] / 50; // 调整料场的堆料高度
    vertices[j + 2] = i / (multi * groundHeight) / multi - groundWidth / 2; // 设置宽度方向的坐标
  }

  texture = new THREE.CanvasTexture(
    generateTexture(data, worldWidth, worldDepth)
  );
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;

  ground = new THREE.Mesh(
    geometry,
    new THREE.MeshBasicMaterial({ map: texture })
  );
  ground.rotation.x = Math.PI / 2;
  ground.position.x += 32;
  ground.position.y += 8.5;
  ground.tick = async () => {
    if (++cnt % 300 !== 0) return;
    // const newData = generateHeight(worldWidth, worldDepth);
    const newData = generateHeight(worldWidth, worldDepth);
    const newGeometry = new THREE.PlaneBufferGeometry(
      groundHeight, //料场的长度
      groundWidth, //料场的宽度
      worldWidth - 1,
      worldDepth - 1
    );
    // geometry.rotateX(-Math.PI / 2);

    const vertices = newGeometry.attributes.position.array;
    const tmp = (await axios.get(scannerDataUrl)).data.data;
    console.log("newData", tmp);

    const begin = worldWidth * (worldDepth - 1);
    const end = begin + worldWidth;
    for (let i = begin; i < end; i++) {
      newData[i] = 0;
    }
    for (let i = 0, j = 0, l = vertices.length; i < l; i++, j += 3) {
      vertices[j + 0] = tmp[j]; // 设置长度方向的坐标
      vertices[j + 1] = tmp[j + 1] / 50; // 调整料场的堆料高度
      vertices[j + 2] = tmp[j + 2]; // 设置宽度方向的坐标
    }
    // for (let i = 0, j = 0, l = vertices.length; i < l; i++, j += 3) {
    //   vertices[j + 0] = (i % (multi * groundHeight)) / multi - groundHeight / 2; // 设置长度方向的坐标
    //   vertices[j + 1] = newData[i] / 50; // 调整料场的堆料高度
    //   vertices[j + 2] = i / (multi * groundHeight) / multi - groundWidth / 2; // 设置宽度方向的坐标
    // }

    let newTexture = new THREE.CanvasTexture(
      generateTexture(newData, worldWidth, worldDepth)
    );
    newTexture.wrapS = THREE.ClampToEdgeWrapping;
    newTexture.wrapT = THREE.ClampToEdgeWrapping;
    newTexture.colorSpace = THREE.SRGBColorSpace;

    ground.material.map = newTexture;
    ground.geometry = newGeometry;
    // ground.rotation.x = Math.PI / 2;
    // ground.position.x += 32;
    // ground.position.y += 8.5;
  };
  return ground;
  // scene.add(mesh);
}

function generateHeight(width, height) {
  const size = width * height,
    // data = new Uint8Array(size),
    data = new Float32Array(size),
    perlin = new ImprovedNoise(),
    z = Math.random() * 100;

  let quality = 1;

  for (let j = 0; j < 4; j++) {
    for (let i = 0; i < size; i++) {
      const x = i % width,
        y = Math.floor(i / width);
      data[i] += Math.abs(
        perlin.noise(x / quality, y / quality, z) * quality * 1.75
      );
    }

    quality *= 5;
  }

  return data;
}

function generateTexture(data, width, height) {
  // bake lighting into texture

  let context, image, imageData, shade;

  const vector3 = new THREE.Vector3(0, 0, 0);

  const sun = new THREE.Vector3(1, 1, 1);
  sun.normalize();

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;

  context = canvas.getContext("2d");
  context.fillStyle = "#000";
  context.fillRect(0, 0, width, height);

  image = context.getImageData(0, 0, canvas.width, canvas.height);
  imageData = image.data;

  for (let i = 0, j = 0, l = imageData.length; i < l; i += 4, j++) {
    vector3.x = data[j - 2] - data[j + 2];
    vector3.y = 2;
    vector3.z = data[j - width * 2] - data[j + width * 2];
    vector3.normalize();

    shade = vector3.dot(sun);

    const scale = 0.5 + data[j] * 0.007;
    imageData[i] = (96 + shade * 128) * scale;
    imageData[i + 1] = (32 + shade * 96) * scale;
    imageData[i + 2] = shade * 96 * scale;

    // const scale = 0.5 + data[j] * 0.003;
    // imageData[i] = (90 + shade * 98) * scale;
    // imageData[i + 1] = (103 + shade * 102) * scale;
    // imageData[i + 2] = (107 + shade * 101) * scale;
  }

  context.putImageData(image, 0, 0);

  // Scaled 4x

  const canvasScaled = document.createElement("canvas");
  canvasScaled.width = width * 4;
  canvasScaled.height = height * 4;

  context = canvasScaled.getContext("2d");
  context.scale(4, 4);
  context.drawImage(canvas, 0, 0);

  image = context.getImageData(0, 0, canvasScaled.width, canvasScaled.height);
  imageData = image.data;

  for (let i = 0, l = imageData.length; i < l; i += 4) {
    const v = ~~(Math.random() * 5);

    imageData[i] += v;
    imageData[i + 1] += v;
    imageData[i + 2] += v;
  }

  context.putImageData(image, 0, 0);

  return canvasScaled;
}

// async function loadGround() {
//   return await init();
// }

export { loadGround };
