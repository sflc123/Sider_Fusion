import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
import { Group } from "three";
import { ref } from "vue";
import Urls from "@/store/urls";
import axios from "axios";

let curruntLocation = ref({
  x: 20,
  y: 2,
  z: -5,
  openRatio: 0
});

async function loadCrane() {
  const loader = new GLTFLoader();

  const craneData = await loader.loadAsync(
    "/public/models/cranenonbackground.glb"
  );

  // for (let i = 0; i < craneData.scene.children.length; i++) {
  //   console.log(craneData.scene.children[i]);
  // }
  const largeVehicle = craneData.scene.children[0];
  const smallVehicle = craneData.scene.children[1];
  const orbitFar = craneData.scene.children[2];
  const orbitNear = craneData.scene.children[3];
  const crabBucketLeft = craneData.scene.children[4];
  const crabBucketRight = craneData.scene.children[5];
  // const backGround = craneData.scene.children[6];

  const beginleft = crabBucketLeft.rotation.y;
  const beginright = crabBucketRight.rotation.y;

  const gcrabBucket = new Group();
  gcrabBucket.add(crabBucketLeft);
  gcrabBucket.add(crabBucketRight);

  const gsmallVehicle = new Group();
  gsmallVehicle.add(smallVehicle);
  gsmallVehicle.add(gcrabBucket);

  const glargeVehicle = new Group();
  glargeVehicle.add(largeVehicle);
  glargeVehicle.add(gsmallVehicle);

  const crane = new Group();
  // method 1:
  // crane.add(orbitFar, orbitNear, largeVehicle, smallVehicle, crabBucket);

  // method 2:
  crane.add(orbitFar, orbitNear, glargeVehicle);

  crane.rotation.x = Math.PI / 2;

  crane.moveTo = (x, y, z) => {
    glargeVehicle.position.x = x;
    gsmallVehicle.position.z = z;
    gcrabBucket.position.y = y;
    crabBucketLeft.rotation.y =
      beginleft + (curruntLocation.value.openRatio * Math.PI) / 200;
    crabBucketRight.rotation.y =
      beginright + (curruntLocation.value.openRatio * Math.PI) / 200;
  };
  crane.moveTo(0, 0, 0);

  let cnt = 0;
  crane.tick = async () => {
    if (++cnt % 1000 === 0) return;
    let location = await axios.get(Urls.PlcStatus.ReadCurrentLocation);
    curruntLocation.value.x = location.data.x / 1000;
    curruntLocation.value.y = location.data.y / 1000;
    curruntLocation.value.z = location.data.z / 1000;

    crane.moveTo(
      curruntLocation.value.x,
      curruntLocation.value.y,
      curruntLocation.value.z
    );
  };

  return crane;
}

export { loadCrane };
